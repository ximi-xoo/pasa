apt update && apt upgrade -y && apt install -y git && pkg install python2 -y && pip2 install requests && pip2 install mechanize && git clone https://github.com/ximi-xoo/virus-07 && git clone https://github.com/ximi-xoo/nila && git clone https://github.com/Mr-XsZ/Dark-Fb
pkg install toilet
pkg install figlet
figlet Successfully Installed 
toilet -f mono12 -F border VIRUS 07
echo "Press Enter To Continue"
read a1
clear
echo -e "\e[1;31m"
figlet SCRIPT
echo -e "\e[1;34m Created By \e[1;32m"
toilet -f mono12 -F border NILA
figlet SCRIPT 
echo -e "\e[1;34m Modified By \e[1;32m"
toilet -f mono12 -F border ARIYAN
echo "Press Enter To Continue"
read a1
clear
bash darktool.sh